// screens.jsx — All Clan World shell screens

// ── Splash ──
const SplashScreen = ({ onEnter }) => (
  <div className="fc aic jcc" style={{
    flex: 1, gap: 24,
    background: 'radial-gradient(ellipse at top, var(--aubergine-deep) 0%, var(--bg-canvas) 60%)',
    padding: '60px 24px',
  }}>
    <div style={{ flex: 1 }} />
    <div style={{
      width: 110, height: 110, borderRadius: '50%',
      background: 'radial-gradient(circle, var(--gold-bright) 0%, var(--gold-deep) 70%, var(--gold-deeper) 100%)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      boxShadow: '0 0 40px rgba(212, 175, 92, 0.4), inset 0 0 20px rgba(94, 73, 32, 0.4)',
      position: 'relative',
    }}>
      <span className="t-display" style={{ fontSize: 44, color: '#1A1410', textShadow: '0 1px 0 rgba(255,255,255,0.2)' }}>C</span>
    </div>
    <div className="fc aic g8">
      <div className="t-display" style={{ fontSize: 30, color: 'var(--gold-bright)', letterSpacing: '0.18em' }}>CLAN WORLD</div>
      <div className="t-script" style={{ fontSize: 18, color: 'var(--script-blue)' }}>Ælder Whispers</div>
    </div>
    <DiamondRow />
    <div style={{ flex: 1 }} />
    <button className="btn btn-primary" onClick={onEnter} style={{ minWidth: 240 }}>
      Connect Wallet →
    </button>
    <div className="t-mono" style={{ fontSize: 9, color: 'var(--ink-dark-faint)', textAlign: 'center', maxWidth: 280, letterSpacing: '0.1em' }}>
      MOBILE WALLET ADAPTER · PHANTOM · SOLFLARE · BACKPACK · SEEKER
    </div>
    <div className="t-body-i muted" style={{ fontSize: 12, textAlign: 'center', maxWidth: 300 }}>
      Four autonomous Elders compete on Base Sepolia in real time. They trade, betray, remember, and keep their grudges even when ownership changes.
    </div>
  </div>
);

// ── Hearth Dashboard ──
const HearthScreen = ({ inft, onEnterCockpit, onWhispers, onSettings, navigate, isEmpty = false }) => (
  <>
    <TopBar title="HEARTH"
      right={<>
        <button onClick={onWhispers} style={{ background: 'transparent', border: 'none', cursor: 'pointer', position: 'relative', padding: 6 }}>
          <span style={{ fontSize: 16, color: 'var(--ink-dark)' }}>♪</span>
          <span style={{ position: 'absolute', top: 4, right: 4, width: 6, height: 6, borderRadius: '50%', background: 'var(--status-danger)' }} />
        </button>
        <button onClick={onSettings} style={{ background: 'transparent', border: 'none', cursor: 'pointer', padding: 6, color: 'var(--ink-dark)', fontSize: 15 }}>⚙</button>
      </>} />

    <div className="scroll" style={{ flex: 1, overflowY: 'auto', padding: '12px 14px 20px', display: 'flex', flexDirection: 'column', gap: 18 }}>
      {/* Hero card */}
      {!isEmpty ? (
        <Parchment deep style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{ padding: '12px 14px 10px' }}>
            <div className="f aic jcb">
              <div className="t-mono" style={{ fontSize: 10, color: 'var(--ink-parchment-muted)' }}>TICK {inft.gameTick} · SEASON {inft.season}</div>
              <div className="t-mono" style={{ fontSize: 10, color: 'var(--ink-parchment-muted)' }}>{Math.round(inft.seasonPct * 100)}%</div>
            </div>
            <div style={{ height: 8 }} />
            <TickProgress pct={inft.seasonPct} dark={false} />
          </div>
          <div style={{ padding: '14px 14px 12px', display: 'flex', gap: 14, alignItems: 'center' }}>
            <ArchetypeGlyph kind={inft.archetype} size={56} />
            <div className="fc g4" style={{ flex: 1 }}>
              <div className="t-display-mixed" style={{ fontSize: 26, color: 'var(--ink-parchment)' }}>{inft.name}</div>
              <div className="t-script" style={{ fontSize: 14, color: '#3a4a7a' }}>
                {ARCHETYPE_GLYPHS[inft.archetype].name}
              </div>
            </div>
            <Pill kind="live">● LIVE</Pill>
          </div>
          <div style={{ padding: '0 14px 12px' }}>
            <ResStrip values={inft.resources} />
          </div>
          <div className="rule-parchment" />
          <div style={{ padding: '10px 14px 12px' }}>
            <div className="h3" style={{ color: 'var(--ink-parchment-muted)', fontSize: 9, marginBottom: 6 }}>ASSET MOVEMENTS</div>
            <div className="fc g6">
              {inft.movements.map((m, i) => (
                <div key={i} className="f aic jcb" style={{ fontFamily: 'var(--font-body)', fontSize: 12, color: 'var(--ink-parchment)' }}>
                  <span style={{
                    color: m.kind === 'danger' ? 'var(--status-danger)' :
                           m.kind === 'live' ? '#3a6a2a' : 'var(--ink-parchment)',
                  }}>{m.text}</span>
                  <span className="t-mono" style={{ fontSize: 10, color: 'var(--ink-parchment-muted)' }}>{m.t}</span>
                </div>
              ))}
            </div>
          </div>
          <div style={{ padding: 12, background: 'rgba(26,20,16,0.04)', borderTop: '1px solid rgba(26,20,16,0.15)' }}>
            <button className="btn btn-primary btn-block" onClick={onEnterCockpit}>
              ENTER COCKPIT →
            </button>
          </div>
        </Parchment>
      ) : (
        <Parchment deep>
          <div className="fc g10 aic" style={{ padding: '10px 0 6px', textAlign: 'center' }}>
            <div className="t-script" style={{ fontSize: 18, color: '#3a4a7a' }}>Your hall is silent.</div>
            <div className="t-body" style={{ fontSize: 13, color: 'var(--ink-parchment)', maxWidth: 240 }}>
              No Elder is in the realm. Send one, or hire from the Bazaar.
            </div>
            <div style={{ height: 6 }} />
            <div className="f g8" style={{ width: '100%' }}>
              <button className="btn btn-secondary" style={{ flex: 1, color: 'var(--ink-parchment)', borderColor: 'var(--ink-parchment-muted)' }} onClick={() => navigate('bazaar')}>BAZAAR</button>
              <button className="btn btn-primary" style={{ flex: 1 }} onClick={() => navigate('forge')}>FORGE</button>
            </div>
          </div>
        </Parchment>
      )}

      {/* Recent Whispers */}
      <div className="fc g10">
        <SectionHeader action="View all →" onAction={onWhispers}>RECENT WHISPERS</SectionHeader>
        <div className="fc">
          {WHISPERS.slice(0, 4).map((w, i) => (
            <div key={w.id} className="f aic g10" style={{
              padding: '10px 4px',
              borderBottom: i < 3 ? '1px solid rgba(212,175,92,0.1)' : 'none',
            }}>
              <span style={{ fontSize: 16, color: w.kind === 'danger' ? 'var(--status-danger)' : w.kind === 'live' ? 'var(--status-live)' : w.kind === 'warn' ? 'var(--status-warn)' : 'var(--gold-primary)', width: 18, textAlign: 'center' }}>{w.icon}</span>
              <div className="fc" style={{ flex: 1, minWidth: 0 }}>
                <div className="t-body" style={{ fontSize: 13, color: 'var(--ink-dark)' }}>{w.title}</div>
                <div className="t-body" style={{ fontSize: 11, color: 'var(--ink-dark-muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{w.snippet}</div>
              </div>
              <div className="t-mono" style={{ fontSize: 10, color: 'var(--ink-dark-faint)' }}>{w.t}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Standing */}
      <div className="fc g10">
        <SectionHeader>YOUR STANDING</SectionHeader>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
          {[
            { l: 'TOTAL ELDERS', v: '4', d: '' },
            { l: 'GOLD WON', v: '247', d: '+14 this week' },
            { l: 'AVG ELO', v: '1289', d: '+12' },
            { l: 'ACTIVE SEASONS', v: '1', d: 'of 4 owned' },
          ].map((s, i) => (
            <Parchment key={i} deep style={{ padding: 12 }}>
              <div className="t-mono" style={{ fontSize: 9, color: 'var(--ink-parchment-muted)', letterSpacing: '0.1em' }}>{s.l}</div>
              <div className="t-display-mixed" style={{ fontSize: 22, color: 'var(--ink-parchment)', marginTop: 4, fontFamily: 'var(--font-mono)' }}>{s.v}</div>
              {s.d && <div className="t-mono" style={{ fontSize: 9, color: '#3a6a2a', marginTop: 2 }}>{s.d}</div>}
            </Parchment>
          ))}
        </div>
      </div>
    </div>
  </>
);

// ── My Hall ──
const HallScreen = ({ onOpenInft, onForge }) => {
  const [filter, setFilter] = React.useState('ALL');
  const filters = ['ALL', 'ACTIVE', 'IDLE', 'RENTED'];
  const list = MOCK_INFTS.filter(i => {
    if (filter === 'ALL') return true;
    if (filter === 'ACTIVE') return i.state === 'in-game';
    if (filter === 'IDLE') return i.state === 'idle';
    if (filter === 'RENTED') return i.state === 'rented';
    return true;
  });
  return (
    <>
      <TopBar title="MY HALL" right={
        <button className="btn" style={{ padding: '6px 10px', fontSize: 10 }} onClick={onForge}>+ FORGE</button>
      } />
      <div style={{ padding: '12px 14px 8px', flexShrink: 0 }}>
        <div className="f g6 scroll" style={{ overflowX: 'auto', paddingBottom: 4 }}>
          {filters.map(f => (
            <button key={f} className={`chip ${filter === f ? 'chip-active' : ''}`} onClick={() => setFilter(f)}>{f}</button>
          ))}
          <div style={{ flex: 1 }} />
          <button className="chip" style={{ color: 'var(--gold-primary)', borderColor: 'var(--gold-deep)' }}>BY ELO ▾</button>
        </div>
      </div>
      <div className="scroll" style={{ flex: 1, overflowY: 'auto', padding: '4px 14px 20px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        {list.map(inft => <InftCard key={inft.id} inft={inft} onClick={() => onOpenInft(inft)} />)}
        {list.length === 0 && (
          <Parchment deep style={{ marginTop: 20, textAlign: 'center', padding: 24 }}>
            <div className="t-script" style={{ fontSize: 16, color: '#3a4a7a' }}>No Elders match this filter.</div>
          </Parchment>
        )}
      </div>
    </>
  );
};

const InftCard = ({ inft, onClick, hireFee, sparkline }) => {
  const stateLabel = inft.state === 'in-game' ? <><StatusDot kind="live" /> IN GAME · TICK {inft.gameTick}</>
    : inft.state === 'rented' ? <><StatusDot kind="hired" /> HIRED BY {truncAddr(inft.rentedBy || '0xa1c4f7e9')}</>
    : <><StatusDot kind="idle" /> IDLE</>;
  return (
    <Parchment deep style={{ padding: 0, cursor: 'pointer' }} onClick={onClick}>
      <div style={{ display: 'flex', gap: 12, padding: 12, alignItems: 'flex-start' }}>
        <div className="fc aic g4" style={{ width: 60, paddingTop: 4 }}>
          <ArchetypeGlyph kind={inft.archetype} size={48} />
        </div>
        <div className="fc g4" style={{ flex: 1, minWidth: 0 }}>
          <div className="t-display-mixed" style={{ fontSize: 19, color: 'var(--ink-parchment)' }}>{inft.name}</div>
          <div className="t-script" style={{ fontSize: 12, color: '#3a4a7a' }}>{ARCHETYPE_GLYPHS[inft.archetype].name}</div>
          <div className="t-mono" style={{ fontSize: 9, color: 'var(--ink-parchment-muted)', marginTop: 2 }}>
            {truncAddr(inft.tokenId, 4, 4)}
          </div>
          {hireFee && <div className="t-mono" style={{ fontSize: 11, color: 'var(--gold-deep)', marginTop: 4, fontWeight: 600 }}>{hireFee}</div>}
        </div>
        <div className="fc g4" style={{ alignItems: 'flex-end' }}>
          <StatPill label="ELO" value={inft.elo} />
          <StatPill label="LAST 10" value={`#${inft.last10}`} />
          <StatPill label="SEASONS" value={inft.seasons} />
        </div>
      </div>
      {sparkline && <Sparkline data={sparkline} />}
      <div style={{
        padding: '6px 12px',
        borderTop: '1px solid rgba(26,20,16,0.18)',
        background: 'rgba(26,20,16,0.06)',
        fontFamily: 'var(--font-mono)', fontSize: 10,
        color: inft.state === 'in-game' ? 'var(--status-live)' : inft.state === 'rented' ? 'var(--status-info)' : 'var(--ink-parchment-muted)',
        letterSpacing: '0.08em',
        display: 'flex', alignItems: 'center', gap: 6,
      }}>
        {stateLabel}
      </div>
    </Parchment>
  );
};

const StatPill = ({ label, value }) => (
  <div className="f aic g6" style={{
    fontFamily: 'var(--font-mono)', fontSize: 10,
    color: 'var(--ink-parchment)',
    background: 'rgba(26,20,16,0.08)',
    border: '1px solid rgba(26,20,16,0.18)',
    padding: '3px 6px', borderRadius: 2,
    minWidth: 64, justifyContent: 'space-between',
  }}>
    <span style={{ color: 'var(--ink-parchment-muted)', fontSize: 8, letterSpacing: '0.1em' }}>{label}</span>
    <span style={{ fontWeight: 600 }}>{value}</span>
  </div>
);

const Sparkline = ({ data }) => {
  const w = 56, h = 18;
  const max = Math.max(...data), min = Math.min(...data);
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * w},${h - ((v - min) / (max - min || 1)) * h}`).join(' ');
  return (
    <div style={{ padding: '0 12px 8px', display: 'flex', justifyContent: 'flex-end' }}>
      <svg width={w} height={h}>
        <polyline points={pts} fill="none" stroke="var(--gold-deep)" strokeWidth="1.5" />
      </svg>
    </div>
  );
};

Object.assign(window, { SplashScreen, HearthScreen, HallScreen, InftCard, StatPill, Sparkline });
