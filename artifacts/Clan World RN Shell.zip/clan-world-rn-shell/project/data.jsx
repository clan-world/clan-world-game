// data.jsx — mock data for Clan World prototype

const MOCK_INFTS = [
  {
    id: 'crimson',
    tokenId: '0xe1de4a8f3c92b71704e5c2a91b3d8f5c2a91b7004',
    name: 'Crimson',
    archetype: 'patient-builder',
    elo: 1247, last10: 4, seasons: 12,
    state: 'in-game',
    gameTick: 259, season: 1, seasonPct: 0.72,
    resources: { gold: 4, wood: 1, iron: 2, wheat: 5, fish: 0, blueprint: 1 },
    bestMonument: 4, bestBase: 5, casualtyPct: '23%',
    minted: '8 months ago', owner: '0x4f2a…81d3',
    teeAttested: true,
    description: 'Slow to anger, slower still to forgive. Crimson hoards stone and waits for the second raid before answering the first.',
    strategy: { trust: -1, aggression: -2, honesty: 1, solo: 0, builder: 2, vengeful: 1, cautious: 2 },
    movements: [
      { t: 'T259', text: 'Bandit raid · -2 wood', kind: 'danger' },
      { t: 'T258', text: 'Trade · +3 iron from Verdant', kind: 'live' },
      { t: 'T257', text: 'Built granary · +1 monument', kind: 'live' },
    ],
    history: [
      { season: 11, rank: 2, gold: 14, event: 'Held the wall through three sieges.', when: '14d ago' },
      { season: 10, rank: 1, gold: 28, event: 'Won via diplomacy. No casualties.', when: '32d ago' },
      { season: 9, rank: 5, gold: 0, event: 'Betrayed at tick 240.', when: '58d ago' },
      { season: 8, rank: 3, gold: 6, event: 'Bandit raid wiped the granary.', when: '79d ago' },
    ],
    kvState: {
      mood: 'cautious',
      trustedClans: '[verdant, ironguard]',
      grudgeAgainst: '0x9a…f7',
      lastWhisperFrom: 'owner',
      pactExpires: 'T+8',
    },
    memory: [
      { t: 'T259', op: 'WRITE', text: 'noted bandit camp · NE quadrant' },
      { t: 'T258', op: 'READ', text: 'recall pact with verdant · expires T267' },
      { t: 'T256', op: 'WRITE', text: 'updated grudge tally vs 0x9a…f7' },
      { t: 'T255', op: 'READ', text: 'consult strategy.honesty for trade' },
    ],
  },
  {
    id: 'thane',
    tokenId: '0x8b2f9c1e7a4d6358f290b41cc3c8e2a91b7d2010',
    name: 'Thane',
    archetype: 'warlord',
    elo: 1389, last10: 2, seasons: 19,
    state: 'idle',
    minted: '14 months ago', owner: '0x4f2a…81d3',
    teeAttested: true,
    description: 'Strikes within ten ticks. If the early gambit fails, recovery is rare.',
    strategy: { trust: -3, aggression: 3, honesty: -1, solo: -1, builder: -2, vengeful: 3, cautious: -2 },
  },
  {
    id: 'evergreen',
    tokenId: '0x3c1a0fe5b8d27a6928b41dd3e8c0a2917b5e3022',
    name: 'Evergreen',
    archetype: 'verdant-warden',
    elo: 1102, last10: 6, seasons: 7,
    state: 'rented',
    rentedBy: '0xa1c4…f7e9',
    minted: '4 months ago', owner: '0x4f2a…81d3',
    teeAttested: true,
    description: 'Husbands grain. A defensive specialist who turns granaries into garrisons.',
    strategy: { trust: 1, aggression: -1, honesty: 2, solo: -2, builder: 1, vengeful: -1, cautious: 1 },
  },
  {
    id: 'dusk',
    tokenId: '0x6d2c8a4f1e9b3705c2a91b3d8e8c0a2917b5d3033',
    name: 'Dusk',
    archetype: 'trickster',
    elo: 1320, last10: 3, seasons: 14,
    state: 'idle',
    minted: '11 months ago', owner: '0x4f2a…81d3',
    teeAttested: true,
    description: 'Keeps two ledgers and remembers which is which.',
    strategy: { trust: -2, aggression: 1, honesty: -3, solo: 0, builder: -1, vengeful: 0, cautious: 0 },
  },
];

const BAZAAR_INFTS = [
  {
    id: 'astor', tokenId: '0xa1f49b2e8c5d7104a6b91c3d8f5c2a91b7d4501',
    name: 'Astor', archetype: 'diplomat',
    elo: 1456, last10: 2, seasons: 22,
    owner: '0x9c2a…48b1', hireFee: '0.5 GOLD / SEASON',
    sparkline: [3, 1, 2, 1, 4, 2, 1, 3, 2, 1],
  },
  {
    id: 'mara', tokenId: '0xc4e8a1d59b3f2607c2a91b3d8e8c0a2917b5d4502',
    name: 'Mara', archetype: 'hermit',
    elo: 1311, last10: 4, seasons: 9,
    owner: '0x21b8…aa44', hireFee: '0.3 GOLD / SEASON',
    sparkline: [5, 3, 4, 2, 3, 4, 5, 4, 3, 4],
  },
  {
    id: 'gauntlet', tokenId: '0x7e8b2a4f9c5d3107a6b91c3d8f5c2a91b7d4503',
    name: 'Gauntlet', archetype: 'warlord',
    elo: 1502, last10: 1, seasons: 31,
    owner: '0xff03…2c1d', hireFee: '0.9 GOLD / SEASON',
    sparkline: [2, 1, 1, 3, 2, 1, 1, 2, 1, 1],
  },
  {
    id: 'corvid', tokenId: '0x52a91b3d8e8c0a2917b5d4504f5c2a91b7d4504',
    name: 'Corvid', archetype: 'trickster',
    elo: 1278, last10: 5, seasons: 11,
    owner: '0x77ee…1a09', hireFee: '0.4 GOLD / SEASON',
    sparkline: [4, 6, 3, 5, 4, 5, 6, 4, 5, 5],
  },
];

const WHISPERS = [
  { id: 'w1', day: 'today', kind: 'danger', icon: '⚔', title: 'Crimson under bandit raid', snippet: 'Lost 2 wood at T259. Counter held.', t: 'T259', unread: true },
  { id: 'w2', day: 'today', kind: 'live',   icon: '◇', title: 'Whisper acknowledged',     snippet: 'Your steering injected at T260 for Crimson.', t: 'T260', unread: true },
  { id: 'w3', day: 'today', kind: 'info',   icon: '◈', title: 'Hire request received',   snippet: '0xa1c4… wishes to hire Evergreen for Season 13.', t: 'T257', unread: false },
  { id: 'w4', day: 'yesterday', kind: 'live', icon: '✦', title: 'Season 11 ended · 2nd place',  snippet: 'Crimson received 14 GOLD.', t: 'T288', unread: false },
  { id: 'w5', day: 'yesterday', kind: 'warn', icon: '⚠', title: 'Pact expiring',          snippet: 'Verdant Wardens pact ends in 8 ticks.', t: 'T255', unread: false },
  { id: 'w6', day: 'wed-6-may', kind: 'info', icon: '◈', title: 'Treasury funded',        snippet: '20 GOLD bridged from Solana.', t: 'T220', unread: false },
];

const TXS = [
  { id: 't1', kind: 'prize', icon: '✦', title: 'Season 11 prize',     sub: 'Crimson · 2nd',           amount: '+14 GOLD', status: 'live', t: '14d ago' },
  { id: 't2', kind: 'mint', icon: '◆', title: 'Forge · Dusk',         sub: 'Mint fee',                amount: '−5 GOLD',  status: 'idle', t: '11mo ago' },
  { id: 't3', kind: 'hire', icon: '→', title: 'Hire · 0xa1c4…',       sub: 'Evergreen · Season 13',   amount: '+0.5 GOLD', status: 'live', t: '2d ago' },
  { id: 't4', kind: 'raid', icon: '⚔', title: 'Raid loss',            sub: 'Crimson · −2 wood',       amount: '—',         status: 'danger', t: 'T259' },
  { id: 't5', kind: 'buy',  icon: '◇', title: 'Bridged from Solana',  sub: '0.42 SOL → 20 GOLD',      amount: '+20 GOLD',  status: 'info', t: '6d ago' },
];

const STRATEGY_PRESETS = {
  diplomat:  { trust: 2, aggression: -1, honesty: 2, solo: 1, builder: 0, vengeful: -2, cautious: 1 },
  warlord:   { trust: -3, aggression: 3, honesty: -1, solo: -1, builder: -2, vengeful: 3, cautious: -2 },
  hermit:    { trust: -2, aggression: -2, honesty: 1, solo: -3, builder: 2, vengeful: 0, cautious: 3 },
  trickster: { trust: -2, aggression: 1, honesty: -3, solo: 0, builder: -1, vengeful: 0, cautious: 0 },
  builder:   { trust: 0, aggression: -2, honesty: 1, solo: 1, builder: 3, vengeful: -1, cautious: 2 },
  custom:    null,
};

const STRATEGY_AXES = [
  { key: 'trust',      left: 'Suspicious', right: 'Trusting',  hint: { '-3': 'Rejects every unverified offer.', '-2': 'Demands escrow before any pact.', '-1': 'Listens, but verifies.', '0': 'Reads the table.', '1': 'Accepts pacts at face value.', '2': 'Tends to believe stated intent.', '3': 'Will follow a stranger into a siege.' } },
  { key: 'aggression', left: 'Restraint',  right: 'Aggression', hint: { '-3': 'Does not strike first, ever.', '-2': 'Strikes only when starved.', '-1': 'Defensive posture.', '0': 'Mirrors the table.', '1': 'Tests neighbors early.', '2': 'Pre-empts perceived threats.', '3': 'Strikes within ten ticks.' } },
  { key: 'honesty',    left: 'Deceit',     right: 'Honesty',   hint: { '-3': 'Keeps a second ledger. Lies plausibly.', '-2': 'Misleads when the cost is low.', '-1': 'Half-truths.', '0': 'Reads the table.', '1': 'Honest by default.', '2': 'Discloses pacts openly.', '3': 'Will not feint, even at cost.' } },
  { key: 'solo',       left: 'Solo',       right: 'Cooperative', hint: { '-3': 'No pacts. No trades.', '-2': 'Rare allies, brief pacts.', '-1': 'Self-reliant.', '0': 'Reads the table.', '1': 'Forms one-season alliances.', '2': 'Anchors the bloc.', '3': 'Cooperates even when betrayed.' } },
  { key: 'builder',    left: 'Gatherer',   right: 'Builder',   hint: { '-3': 'Eats what is harvested. Builds nothing.', '-2': 'Lean settlement.', '-1': 'Modest infrastructure.', '0': 'Reads the table.', '1': 'Reinvests harvest.', '2': 'Slow accumulation. Trades wood for time.', '3': 'Builds monuments above all.' } },
  { key: 'vengeful',   left: 'Forgiving',  right: 'Vengeful',  hint: { '-3': 'Forgets within three ticks.', '-2': 'Forgives openly.', '-1': 'Lets minor slights pass.', '0': 'Reads the table.', '1': 'Remembers grudges.', '2': 'Settles every betrayal.', '3': 'Burns down the betrayer.' } },
  { key: 'cautious',   left: 'Bold',       right: 'Cautious',  hint: { '-3': 'Acts before thinking. Often.', '-2': 'Bold gambits.', '-1': 'Improvises.', '0': 'Reads the table.', '1': 'Plans two ticks ahead.', '2': 'Pre-models every move.', '3': 'Will not act without three confirmations.' } },
];

const CHAT_LOG = [
  { kind: 'human', t: 'T254', text: 'Hold the granary. Don\'t take the gambit on iron.' },
  { kind: 'orch', t: 'T254', text: '▸ Whisper acknowledged · injected at T255' },
  { kind: 'whisper', t: 'T256', target: 'VERDANT', text: 'Pact for the season? My wood for your iron at parity.' },
  { kind: 'orch', t: 'T257', text: '▸ Pact accepted by Verdant Wardens · expires T+10' },
  { kind: 'human', t: 'T258', text: 'Watch the bandit camp NE. Don\'t engage.' },
  { kind: 'orch', t: 'T259', text: '▸ Whisper acknowledged · injected at T260' },
];

Object.assign(window, {
  MOCK_INFTS, BAZAAR_INFTS, WHISPERS, TXS,
  STRATEGY_PRESETS, STRATEGY_AXES, CHAT_LOG,
});
