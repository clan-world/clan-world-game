// screens-2.jsx — INFT Detail, Strategy Editor, Steering Console, Forge

// ── INFT Detail ──
const InftDetailScreen = ({ inft, onBack, onEdit, onWhisper, onCockpit, isBazaar = false, onHire, navigate }) => {
  const [tab, setTab] = React.useState('DOSSIER');
  const tabs = isBazaar ? ['DOSSIER', 'STRATEGY', 'HISTORY'] : ['DOSSIER', 'STRATEGY', 'MEMORY', 'HISTORY'];

  return (
    <>
      <TopBar title={inft.name.toUpperCase()} onBack={onBack}
        right={<button style={{ background: 'transparent', border: 'none', color: 'var(--ink-dark)', fontSize: 18, cursor: 'pointer' }}>⋯</button>} />

      <div className="scroll" style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column' }}>
        {/* Hero band */}
        <div className="parchment" style={{ padding: '20px 16px 18px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, borderBottom: '1px solid var(--gold-primary)' }}>
          <ArchetypeGlyph kind={inft.archetype} size={70} />
          <div className="t-display-mixed" style={{ fontSize: 30, color: 'var(--ink-parchment)' }}>{inft.name}</div>
          <div className="t-script" style={{ fontSize: 15, color: '#3a4a7a' }}>{ARCHETYPE_GLYPHS[inft.archetype].name}</div>
          <div className="f aic g8" style={{ marginTop: 4 }}>
            <span className="t-mono" style={{ fontSize: 10, color: 'var(--ink-parchment-muted)' }}>{truncAddr(inft.tokenId, 6, 6)}</span>
            <span style={{ fontSize: 9, color: 'var(--ink-parchment-muted)', cursor: 'pointer' }}>⎘</span>
          </div>
          <div className="f aic g6" style={{ marginTop: 2 }}>
            <span style={{ color: 'var(--status-live)', fontSize: 10 }}>●</span>
            <span className="t-mono" style={{ fontSize: 9, color: 'var(--status-live)', letterSpacing: '0.1em' }}>TEE-ATTESTED · ERC-7857</span>
          </div>
        </div>

        {/* Status strip */}
        <div className="f aic" style={{
          padding: '8px 16px', background: 'var(--bg-elevated)',
          borderBottom: '1px solid rgba(212,175,92,0.2)',
          fontFamily: 'var(--font-mono)', fontSize: 10, letterSpacing: '0.1em',
          color: inft.state === 'in-game' ? 'var(--status-live)' : 'var(--ink-dark-muted)',
        }}>
          {inft.state === 'in-game' ? (
            <>● IN GAME · TICK {inft.gameTick} · SEASON {inft.season}</>
          ) : inft.state === 'rented' ? (
            <>→ HIRED OUT · SEASON 13</>
          ) : (
            <>○ IDLE · LAST PLAYED {inft.history?.[0]?.when || '—'}</>
          )}
        </div>

        {/* Tab strip */}
        <div className="f" style={{
          background: 'var(--bg-canvas)',
          borderBottom: '1px solid rgba(212,175,92,0.2)',
          padding: '0 8px',
        }}>
          {tabs.map(t => (
            <button key={t} onClick={() => setTab(t)} style={{
              flex: 1, background: 'transparent', border: 'none', cursor: 'pointer',
              padding: '12px 4px',
              fontFamily: 'var(--font-display)', fontSize: 10, letterSpacing: '0.14em',
              color: tab === t ? 'var(--gold-bright)' : 'var(--ink-dark-faint)',
              borderBottom: `2px solid ${tab === t ? 'var(--gold-bright)' : 'transparent'}`,
            }}>{t}</button>
          ))}
        </div>

        <div style={{ flex: 1, padding: '16px 14px', display: 'flex', flexDirection: 'column', gap: 14 }}>
          {tab === 'DOSSIER' && <DossierTab inft={inft} />}
          {tab === 'STRATEGY' && <StrategyReadOnly inft={inft} onEdit={!isBazaar ? onEdit : null} onWhisper={!isBazaar ? onWhisper : null} />}
          {tab === 'MEMORY' && <MemoryTab inft={inft} />}
          {tab === 'HISTORY' && <HistoryTab inft={inft} />}
        </div>

        {/* Bottom action bar */}
        <div style={{
          flexShrink: 0, padding: 12, gap: 8,
          background: 'var(--bg-canvas)',
          borderTop: '1px solid rgba(212,175,92,0.3)',
          display: 'flex',
        }}>
          {isBazaar ? (
            <button className="btn btn-primary btn-block" onClick={onHire}>HIRE · {inft.hireFee}</button>
          ) : inft.state === 'in-game' ? (
            <button className="btn btn-primary btn-block" onClick={onCockpit}>OPEN COCKPIT →</button>
          ) : inft.state === 'rented' ? (
            <button className="btn btn-secondary btn-block">WITHDRAW AT SEASON END</button>
          ) : (
            <>
              <button className="btn btn-secondary" style={{ flex: 1 }}>LIST FOR HIRE</button>
              <button className="btn btn-primary" style={{ flex: 1 }}>ENTER A SEASON</button>
            </>
          )}
        </div>
      </div>
    </>
  );
};

const DossierTab = ({ inft }) => (
  <div className="fc g14">
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 6 }}>
      <MiniStat l="ELO" v={inft.elo} />
      <MiniStat l="SEASONS" v={inft.seasons} />
      <MiniStat l="LAST 10" v={`#${inft.last10}`} />
      <MiniStat l="BEST MONUMENT" v={inft.bestMonument || '—'} />
      <MiniStat l="BEST BASE" v={inft.bestBase || '—'} />
      <MiniStat l="CASUALTY %" v={inft.casualtyPct || '—'} />
    </div>

    <Parchment deep style={{ padding: 14 }}>
      <div className="t-body-i" style={{ fontSize: 14, color: 'var(--ink-parchment)', lineHeight: 1.45 }}>
        {inft.description}
      </div>
    </Parchment>

    <Stone>
      <div className="fc g8">
        <div className="f jcb">
          <span className="h3" style={{ color: 'var(--ink-dark-muted)' }}>OWNER</span>
          <span className="t-mono" style={{ fontSize: 11, color: 'var(--ink-mono)' }}>{inft.owner}</span>
        </div>
        <div className="rule-gold-soft" />
        <div className="f jcb">
          <span className="h3" style={{ color: 'var(--ink-dark-muted)' }}>MINTED</span>
          <span className="t-body" style={{ fontSize: 12, color: 'var(--ink-dark)' }}>{inft.minted}</span>
        </div>
        <div className="rule-gold-soft" />
        <div className="f jcb">
          <span className="h3" style={{ color: 'var(--ink-dark-muted)' }}>HARNESS</span>
          <span className="t-mono" style={{ fontSize: 11, color: 'var(--ink-mono)' }}>CLAUDE-CODE · v1</span>
        </div>
      </div>
    </Stone>
  </div>
);

const MiniStat = ({ l, v }) => (
  <Parchment deep style={{ padding: '10px 8px', textAlign: 'center' }}>
    <div className="t-mono" style={{ fontSize: 8, color: 'var(--ink-parchment-muted)', letterSpacing: '0.1em' }}>{l}</div>
    <div style={{ fontFamily: 'var(--font-mono)', fontSize: 18, color: 'var(--ink-parchment)', fontWeight: 600, marginTop: 2 }}>{v}</div>
  </Parchment>
);

const StrategyReadOnly = ({ inft, onEdit, onWhisper }) => (
  <div className="fc g14">
    <Parchment deep>
      <div className="fc g14">
        {STRATEGY_AXES.map(ax => {
          const v = inft.strategy?.[ax.key] ?? 0;
          const pct = ((v + 3) / 6) * 100;
          return (
            <div key={ax.key} className="fc g4">
              <div className="f jcb aic">
                <span className="h3" style={{ color: 'var(--ink-parchment)', fontSize: 10 }}>{ax.key.toUpperCase()}</span>
                <span className="t-mono" style={{ fontSize: 11, color: 'var(--ink-parchment)', fontWeight: 600 }}>{v > 0 ? `+${v}` : v}</span>
              </div>
              <div style={{ position: 'relative', height: 18 }}>
                <div style={{ position: 'absolute', top: '50%', left: 0, right: 0, height: 2, background: 'rgba(26,20,16,0.25)', transform: 'translateY(-50%)' }} />
                <div style={{ position: 'absolute', top: '50%', left: `${pct}%`, transform: 'translate(-50%, -50%) rotate(45deg)', width: 10, height: 10, background: 'var(--ink-parchment)' }} />
              </div>
              <div className="f jcb">
                <span className="t-script" style={{ fontSize: 12, color: '#3a4a7a' }}>{ax.left}</span>
                <span className="t-script" style={{ fontSize: 12, color: '#3a4a7a' }}>{ax.right}</span>
              </div>
            </div>
          );
        })}
      </div>
    </Parchment>

    {onEdit && (
      <div className="fc g8">
        <button className="btn btn-primary btn-block" onClick={onEdit}>EDIT STRATEGY</button>
        <button className="btn btn-secondary btn-block" onClick={onWhisper} disabled={inft.state !== 'in-game'}>
          {inft.state === 'in-game' ? 'SEND WHISPER' : 'WHISPER · AVAILABLE WHEN IN A SEASON'}
        </button>
      </div>
    )}
  </div>
);

const MemoryTab = ({ inft }) => {
  const kv = inft.kvState || {};
  const mem = inft.memory || [];
  return (
    <div className="fc g14">
      <Stone>
        <SectionHeader>KV STATE</SectionHeader>
        <div className="fc g6" style={{ marginTop: 10 }}>
          {Object.entries(kv).map(([k, v], i) => (
            <div key={k} className="f jcb" style={{ padding: '4px 0', borderBottom: i < Object.keys(kv).length - 1 ? '1px solid rgba(212,175,92,0.1)' : 'none' }}>
              <span className="t-body" style={{ fontSize: 13, color: 'var(--ink-dark)' }}>{k}</span>
              <span className="t-mono" style={{ fontSize: 11, color: typeof v === 'string' && v.startsWith('[') ? 'var(--script-blue)' : 'var(--ink-mono)' }}>{v}</span>
            </div>
          ))}
        </div>
      </Stone>

      <Stone>
        <SectionHeader>MEMORY · CRUD</SectionHeader>
        <div className="fc g8" style={{ marginTop: 10 }}>
          {mem.map((m, i) => (
            <div key={i} className="f g10 aic" style={{ padding: '4px 0' }}>
              <span className="t-mono" style={{ fontSize: 9, color: 'var(--ink-mono)', minWidth: 32 }}>{m.t}</span>
              <span style={{
                fontFamily: 'var(--font-mono)', fontSize: 9,
                color: m.op === 'WRITE' ? 'var(--status-warn)' : 'var(--status-info)',
                background: m.op === 'WRITE' ? 'rgba(201,155,79,0.12)' : 'rgba(90,123,168,0.12)',
                padding: '2px 5px', letterSpacing: '0.06em', minWidth: 42, textAlign: 'center',
              }}>{m.op}</span>
              <span className="t-body" style={{ fontSize: 12, color: 'var(--ink-dark)' }}>{m.text}</span>
            </div>
          ))}
        </div>
      </Stone>
    </div>
  );
};

const HistoryTab = ({ inft }) => (
  <div className="fc g8">
    {(inft.history || []).map((h, i) => (
      <Parchment key={i} deep style={{ padding: 12 }}>
        <div className="f jcb aic">
          <div className="f aic g8">
            {h.rank === 1 && <span style={{ fontSize: 14, color: 'var(--gold-bright)' }}>♛</span>}
            <span className="t-display" style={{ fontSize: 12, color: 'var(--ink-parchment)' }}>SEASON {h.season}</span>
            <span className="t-mono" style={{ fontSize: 10, color: 'var(--ink-parchment-muted)' }}>FINISH #{h.rank}</span>
          </div>
          <span className="t-mono" style={{ fontSize: 11, color: h.gold > 0 ? '#3a6a2a' : 'var(--ink-parchment-muted)' }}>
            {h.gold > 0 ? `+${h.gold} GOLD` : '— gold'}
          </span>
        </div>
        <div className="t-body-i" style={{ fontSize: 12, color: 'var(--ink-parchment-muted)', marginTop: 6 }}>{h.event}</div>
        <div className="t-mono" style={{ fontSize: 9, color: 'var(--ink-parchment-faint)', marginTop: 4 }}>{h.when}</div>
      </Parchment>
    ))}
  </div>
);

// ── Strategy Editor ──
const StrategyEditor = ({ inft, onBack, onSave }) => {
  const [strat, setStrat] = React.useState({ ...inft.strategy });
  const [preset, setPreset] = React.useState('CUSTOM');
  const presets = ['DIPLOMAT', 'WARLORD', 'HERMIT', 'TRICKSTER', 'BUILDER', 'CUSTOM'];

  const applyPreset = (p) => {
    setPreset(p);
    if (p === 'CUSTOM') return;
    const k = p.toLowerCase();
    if (STRATEGY_PRESETS[k]) setStrat({ ...STRATEGY_PRESETS[k] });
  };

  const update = (key, v) => {
    setStrat(s => ({ ...s, [key]: v }));
    setPreset('CUSTOM');
  };

  return (
    <>
      <TopBar title="EDIT STRATEGY" onBack={onBack} sub={inft.name.toUpperCase()} />
      <div className="scroll" style={{ flex: 1, overflowY: 'auto', padding: '12px 14px 16px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div>
          <div className="h3 muted" style={{ marginBottom: 8 }}>PRESETS</div>
          <div className="f g6 scroll" style={{ overflowX: 'auto', paddingBottom: 4 }}>
            {presets.map(p => (
              <button key={p} className={`chip ${preset === p ? 'chip-active' : ''}`} onClick={() => applyPreset(p)}>{p}</button>
            ))}
          </div>
        </div>

        <Parchment deep style={{ padding: 16 }}>
          <div className="fc g16">
            {STRATEGY_AXES.map(ax => {
              const v = strat[ax.key] ?? 0;
              return (
                <div key={ax.key} className="fc g6">
                  <div className="f jcb aic">
                    <span className="h3" style={{ color: 'var(--ink-parchment)', fontSize: 10 }}>{ax.key.toUpperCase()}</span>
                    <span className="t-mono" style={{ fontSize: 12, color: 'var(--ink-parchment)', fontWeight: 600 }}>{v > 0 ? `+${v}` : v}</span>
                  </div>
                  <SliderInk value={v} onChange={(nv) => update(ax.key, nv)} />
                  <div className="f jcb">
                    <span className="t-script" style={{ fontSize: 12, color: '#3a4a7a' }}>{ax.left}</span>
                    <span className="t-script" style={{ fontSize: 12, color: '#3a4a7a' }}>{ax.right}</span>
                  </div>
                  <div className="t-body-i" style={{ fontSize: 11, color: 'var(--ink-parchment-muted)', minHeight: 14 }}>
                    {ax.hint[String(v)] || ax.hint['0']}
                  </div>
                </div>
              );
            })}
          </div>
        </Parchment>
      </div>
      <div style={{ flexShrink: 0, padding: 12, background: 'var(--bg-canvas)', borderTop: '1px solid rgba(212,175,92,0.3)' }}>
        <div className="t-mono" style={{ fontSize: 9, color: 'var(--ink-dark-muted)', textAlign: 'center', marginBottom: 8, letterSpacing: '0.1em' }}>
          STRATEGY UPDATE · 1 GOLD · EFFECTIVE NEXT TICK
        </div>
        <div className="f g8">
          <button className="btn btn-secondary" style={{ flex: 1 }} onClick={onBack}>CANCEL</button>
          <button className="btn btn-primary" style={{ flex: 1 }} onClick={() => onSave(strat)}>SAVE · 1 GOLD</button>
        </div>
      </div>
    </>
  );
};

// Slider with ink thumb (for parchment surfaces)
const SliderInk = ({ value, onChange, min = -3, max = 3 }) => {
  const ref = React.useRef();
  const pct = ((value - min) / (max - min)) * 100;
  const [drag, setDrag] = React.useState(false);
  const move = (e) => {
    if (!ref.current) return;
    const r = ref.current.getBoundingClientRect();
    const x = (e.touches ? e.touches[0].clientX : e.clientX) - r.left;
    const p = Math.max(0, Math.min(1, x / r.width));
    onChange?.(Math.round(min + p * (max - min)));
  };
  React.useEffect(() => {
    if (!drag) return;
    const m = e => move(e);
    const u = () => setDrag(false);
    window.addEventListener('mousemove', m); window.addEventListener('mouseup', u);
    window.addEventListener('touchmove', m); window.addEventListener('touchend', u);
    return () => {
      window.removeEventListener('mousemove', m); window.removeEventListener('mouseup', u);
      window.removeEventListener('touchmove', m); window.removeEventListener('touchend', u);
    };
  });
  return (
    <div ref={ref} style={{ position: 'relative', height: 24, cursor: 'pointer' }}
      onMouseDown={(e) => { setDrag(true); move(e); }}
      onTouchStart={(e) => { setDrag(true); move(e); }}>
      <div style={{ position: 'absolute', top: '50%', left: 0, right: 0, height: 2, background: 'rgba(26,20,16,0.3)', transform: 'translateY(-50%)' }} />
      {/* Tick marks */}
      {Array.from({ length: 7 }).map((_, i) => (
        <div key={i} style={{
          position: 'absolute', top: '50%', left: `${(i / 6) * 100}%`,
          width: 1, height: 6, background: 'rgba(26,20,16,0.25)',
          transform: 'translate(-50%, -50%)',
        }} />
      ))}
      <div style={{
        position: 'absolute', top: '50%', left: `${pct}%`,
        transform: 'translate(-50%, -50%) rotate(45deg)',
        width: 14, height: 14, background: 'var(--ink-parchment)',
        boxShadow: '0 0 0 2px var(--bg-parchment-dim), 0 2px 4px rgba(0,0,0,0.2)',
      }} />
    </div>
  );
};

// ── Steering Console ──
const SteeringConsole = ({ inft, onBack, onSend }) => {
  const [draft, setDraft] = React.useState('');
  const [log, setLog] = React.useState(CHAT_LOG);
  const suggestions = ['Pace yourself', 'Push aggressive', 'Defend the wall', 'Watch the bandits', 'Trade for wood'];

  const send = () => {
    if (!draft.trim()) return;
    const t = `T${260 + log.filter(l => l.kind === 'human').length}`;
    setLog([...log, { kind: 'human', t, text: draft, pending: true }]);
    setDraft('');
    setTimeout(() => {
      setLog(l => [...l, { kind: 'orch', t, text: `▸ Whisper acknowledged · injected at ${t}` }]);
    }, 900);
    onSend?.();
  };

  return (
    <>
      <TopBar title={`WHISPER · ${inft.name.toUpperCase()}`} onBack={onBack}
        right={<span className="t-mono" style={{ fontSize: 10, color: 'var(--status-live)' }}>● TICK {inft.gameTick}</span>} />

      {/* Context strip */}
      <div className="f aic g10" style={{
        padding: '8px 14px', background: 'var(--bg-elevated)',
        borderBottom: '1px solid rgba(212,175,92,0.15)', flexShrink: 0,
      }}>
        <ResStrip values={inft.resources} compact dark />
      </div>

      <div className="scroll" style={{ flex: 1, overflowY: 'auto', padding: '14px 14px 8px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        {log.map((m, i) => <ChatBubble key={i} msg={m} />)}
      </div>

      {/* Suggestions */}
      <div style={{ flexShrink: 0, padding: '6px 14px', borderTop: '1px solid rgba(212,175,92,0.1)' }}>
        <div className="f g6 scroll" style={{ overflowX: 'auto', paddingBottom: 4 }}>
          {suggestions.map(s => (
            <button key={s} className="chip" style={{ flexShrink: 0 }} onClick={() => setDraft(d => d ? `${d} ${s}` : s)}>{s}</button>
          ))}
        </div>
      </div>

      {/* Input */}
      <div style={{ flexShrink: 0, padding: 10, background: 'var(--bg-canvas)', borderTop: '1px solid rgba(212,175,92,0.3)', display: 'flex', gap: 8 }}>
        <input value={draft} onChange={e => setDraft(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter') send(); }}
          placeholder="Whisper into the next tick…"
          style={{
            flex: 1, background: 'var(--bg-elevated)',
            border: '1px solid var(--gold-deep)', color: 'var(--ink-dark)',
            padding: '10px 12px', borderRadius: 2,
            fontFamily: 'var(--font-body)', fontSize: 13,
            outline: 'none',
          }} />
        <button className="btn btn-primary" onClick={send} disabled={!draft.trim()} style={{ minWidth: 90 }}>WHISPER</button>
      </div>
    </>
  );
};

const ChatBubble = ({ msg }) => {
  if (msg.kind === 'human') return (
    <div style={{ alignSelf: 'flex-end', maxWidth: '82%' }}>
      <div className="parchment-light" style={{ padding: '8px 12px', borderRadius: 2, border: '1px solid var(--gold-primary)' }}>
        <div className="t-body" style={{ fontSize: 13, color: 'var(--ink-parchment)' }}>{msg.text}</div>
      </div>
      <div className="t-mono" style={{ fontSize: 9, color: 'var(--ink-dark-faint)', marginTop: 4, textAlign: 'right' }}>
        {msg.t}{msg.pending ? ' · sending…' : ''}
      </div>
    </div>
  );
  if (msg.kind === 'orch') return (
    <div style={{ alignSelf: 'center', maxWidth: '90%', textAlign: 'center' }}>
      <div className="t-body-i" style={{ fontSize: 12, color: 'var(--ink-dark-muted)' }}>{msg.text}</div>
      <div className="t-mono" style={{ fontSize: 9, color: 'var(--ink-dark-faint)', marginTop: 2 }}>{msg.t}</div>
    </div>
  );
  if (msg.kind === 'whisper') return (
    <div style={{ alignSelf: 'flex-start', maxWidth: '82%' }}>
      <div className="f g6 aic" style={{ marginBottom: 4 }}>
        <span className="t-mono" style={{ fontSize: 8, color: 'var(--gold-primary)', background: 'rgba(212,175,92,0.12)', padding: '2px 5px', letterSpacing: '0.1em' }}>↗ {msg.target}</span>
      </div>
      <div className="stone" style={{ padding: '8px 12px', borderRadius: 2, border: '1px solid rgba(212,175,92,0.3)' }}>
        <div className="t-body-i" style={{ fontSize: 13, color: 'var(--ink-dark)' }}>"{msg.text}"</div>
      </div>
      <div className="t-mono" style={{ fontSize: 9, color: 'var(--ink-dark-faint)', marginTop: 4 }}>{msg.t}</div>
    </div>
  );
  return null;
};

Object.assign(window, {
  InftDetailScreen, DossierTab, MiniStat, StrategyReadOnly, MemoryTab, HistoryTab,
  StrategyEditor, SliderInk, SteeringConsole, ChatBubble,
});
