// shared.jsx — common UI primitives for Clan World

const Diamond = ({ size = 6, color, style, className = '' }) => (
  <span className={className} style={{
    display: 'inline-block', width: size, height: size,
    background: color || 'currentColor', transform: 'rotate(45deg)',
    ...style,
  }} />
);

const DiamondRow = ({ count = 3, color = 'var(--gold-primary)', size = 6 }) => (
  <div className="f aic jcc g14" style={{ color }}>
    <span style={{ flex: 1, height: 1, background: 'linear-gradient(to right, transparent, currentColor 80%)', maxWidth: 80 }} />
    {Array.from({ length: count }).map((_, i) => <Diamond key={i} size={size} />)}
    <span style={{ flex: 1, height: 1, background: 'linear-gradient(to right, currentColor 20%, transparent)', maxWidth: 80 }} />
  </div>
);

const SectionHeader = ({ children, action, onAction, dark = true, className = '' }) => (
  <div className={`fc g6 ${className}`}>
    <div className="f aic jcb">
      <div className="h3" style={{ color: dark ? 'var(--ink-dark)' : 'var(--ink-parchment)' }}>
        {children}
      </div>
      {action && (
        <button onClick={onAction} className="t-script" style={{
          background: 'transparent', border: 'none', cursor: 'pointer',
          color: 'var(--gold-primary)', fontSize: 13, padding: 0,
        }}>{action}</button>
      )}
    </div>
    <div className="rule-gold" style={{ opacity: dark ? 0.7 : 0.55 }} />
  </div>
);

const StatusDot = ({ kind = 'live' }) => {
  const map = {
    live: { glyph: '●', color: 'var(--status-live)' },
    idle: { glyph: '○', color: 'var(--ink-dark-muted)' },
    hired: { glyph: '→', color: 'var(--status-info)' },
    warn: { glyph: '●', color: 'var(--status-warn)' },
    danger: { glyph: '●', color: 'var(--status-danger)' },
  };
  const s = map[kind] || map.live;
  return <span style={{ color: s.color, fontSize: 10 }}>{s.glyph}</span>;
};

const Pill = ({ kind = 'live', children }) => (
  <span className={`pill pill-${kind}`}>{children}</span>
);

// Resource: use simple colored geometric shapes (no copyrighted pixel art)
const RES = {
  gold:      { glyph: '◇', color: '#D4AF5C', label: 'GOLD' },
  wood:      { glyph: '▤', color: '#8B6B3F', label: 'WOOD' },
  iron:      { glyph: '▰', color: '#7A8590', label: 'IRON' },
  wheat:     { glyph: '⁂', color: '#C7A14F', label: 'WHEAT' },
  fish:      { glyph: '◗', color: '#5A8AA0', label: 'FISH' },
  blueprint: { glyph: '⁋', color: '#A89A78', label: 'PLAN' },
};

const ResIcon = ({ kind, size = 14 }) => (
  <span className="res-icon" style={{ color: RES[kind]?.color, fontSize: size + 2 }}>
    {RES[kind]?.glyph}
  </span>
);

const ResStrip = ({ values, compact = false, dark = false }) => (
  <div className="f aic" style={{ gap: compact ? 8 : 12 }}>
    {Object.entries(values).map(([k, v]) => (
      <div key={k} className="f aic g4" style={{
        fontFamily: 'var(--font-mono)', fontSize: compact ? 10 : 11,
        color: dark ? 'var(--ink-dark)' : 'var(--ink-parchment)',
      }}>
        <ResIcon kind={k} size={compact ? 12 : 13} />
        <span>{v}</span>
      </div>
    ))}
  </div>
);

// Archetype glyph: a unique runic mark per archetype
const ARCHETYPE_GLYPHS = {
  'patient-builder':  { mark: '⏃', color: '#A89A78', name: 'Patient Builder', short: 'A slow, deep accumulator. Trades wood for time.' },
  'warlord':          { mark: '⚔', color: '#A04A3F', name: 'Warlord', short: 'Strikes early. Begins enemies, not friendships.' },
  'diplomat':         { mark: '✺', color: '#5A7BA8', name: 'Diplomat', short: 'Seeks pacts. A treaty is a tool.' },
  'hermit':           { mark: '☖', color: '#8C6F3A', name: 'Hermit', short: 'Builds inward. Speaks rarely. Remembers all.' },
  'trickster':        { mark: '✦', color: '#9B6FA0', name: 'Trickster', short: 'Lies plausibly. Keeps a second ledger.' },
  'verdant-warden':   { mark: '✧', color: '#6B8E5C', name: 'Verdant Warden', short: 'Husbands grain. Fights only at the wall.' },
};

const ArchetypeGlyph = ({ kind, size = 56, framed = true }) => {
  const a = ARCHETYPE_GLYPHS[kind] || ARCHETYPE_GLYPHS['patient-builder'];
  return (
    <div style={{
      width: size, height: size, position: 'relative',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      flexShrink: 0,
    }}>
      {framed && (
        <svg viewBox="0 0 100 100" style={{ position: 'absolute', inset: 0 }}>
          <polygon points="50,4 96,50 50,96 4,50" fill="none" stroke="var(--gold-deep)" strokeWidth="1.5" opacity="0.7" />
          <polygon points="50,12 88,50 50,88 12,50" fill="none" stroke="var(--gold-primary)" strokeWidth="0.8" opacity="0.5" />
        </svg>
      )}
      <span style={{
        fontFamily: 'var(--font-display)', fontWeight: 600,
        fontSize: size * 0.42,
        color: a.color,
        textShadow: `0 0 8px ${a.color}50`,
        position: 'relative',
      }}>{a.mark}</span>
    </div>
  );
};

// Truncate hex
const truncAddr = (s, head = 4, tail = 4) =>
  s ? `${s.slice(0, head + 2)}…${s.slice(-tail)}` : '';

// Parchment card
const Parchment = ({ children, deep = false, style, className = '' }) => (
  <div className={`${deep ? 'parchment' : 'parchment-light'} ${className}`} style={{
    border: '1px solid var(--gold-primary)',
    borderRadius: 2,
    padding: 16,
    ...style,
  }}>{children}</div>
);

const Stone = ({ children, style, className = '' }) => (
  <div className={`stone ${className}`} style={{
    border: '1px solid rgba(212, 175, 92, 0.3)',
    borderRadius: 2,
    padding: 16,
    ...style,
  }}>{children}</div>
);

// Top bar (in-screen)
const TopBar = ({ title, onBack, right, sub }) => (
  <div className="f aic jcb" style={{
    height: 52, padding: '0 16px', flexShrink: 0,
    background: 'var(--bg-canvas)',
    borderBottom: '1px solid rgba(212, 175, 92, 0.15)',
  }}>
    <div className="f aic g10">
      {onBack && (
        <button onClick={onBack} style={{
          background: 'transparent', border: 'none', cursor: 'pointer',
          color: 'var(--gold-primary)', fontSize: 18, padding: 4,
        }}>←</button>
      )}
      <div className="fc">
        <div className="h3" style={{ color: 'var(--ink-dark)' }}>{title}</div>
        {sub && <div className="t-mono" style={{ fontSize: 9, color: 'var(--ink-dark-muted)' }}>{sub}</div>}
      </div>
    </div>
    <div className="f aic g10">{right}</div>
  </div>
);

// Tab bar (bottom)
const TabBar = ({ active, onChange }) => {
  const tabs = [
    { id: 'hearth', label: 'HEARTH', glyph: '🜂' },
    { id: 'hall', label: 'HALL', glyph: '⛨' },
    { id: 'bazaar', label: 'BAZAAR', glyph: '⚖' },
    { id: 'treasury', label: 'TREASURY', glyph: '◈' },
  ];
  return (
    <div className="f" style={{
      height: 64, flexShrink: 0,
      background: 'var(--bg-canvas)',
      borderTop: '1px solid var(--gold-primary)',
    }}>
      {tabs.map(t => {
        const on = active === t.id;
        return (
          <button key={t.id} onClick={() => onChange(t.id)} style={{
            flex: 1, background: 'transparent', border: 'none', cursor: 'pointer',
            display: 'flex', flexDirection: 'column', alignItems: 'center',
            justifyContent: 'center', gap: 4, padding: '6px 0',
            color: on ? 'var(--gold-bright)' : 'var(--ink-dark-faint)',
            position: 'relative',
          }}>
            <span style={{ fontSize: 20, lineHeight: 1 }}>{t.glyph}</span>
            <span style={{
              fontFamily: 'var(--font-display)', fontSize: 9,
              letterSpacing: '0.14em', fontWeight: 500,
            }}>{t.label}</span>
            {on && <span style={{
              position: 'absolute', bottom: 6, height: 1, width: 20,
              background: 'var(--gold-bright)',
            }} />}
          </button>
        );
      })}
    </div>
  );
};

// Tick progress bar
const TickProgress = ({ pct = 0.72, dark = true }) => (
  <div style={{
    height: 3, background: dark ? 'rgba(212,175,92,0.2)' : 'rgba(26,20,16,0.15)',
    position: 'relative', overflow: 'hidden',
  }}>
    <div style={{
      position: 'absolute', left: 0, top: 0, bottom: 0,
      width: `${pct * 100}%`,
      background: 'linear-gradient(to right, var(--gold-deep), var(--gold-bright))',
    }} />
  </div>
);

// Slider with diamond thumb
const Slider = ({ value, onChange, min = -3, max = 3, leftLabel, rightLabel }) => {
  const pct = ((value - min) / (max - min)) * 100;
  const ref = React.useRef();
  const [drag, setDrag] = React.useState(false);
  const move = (e) => {
    if (!ref.current) return;
    const r = ref.current.getBoundingClientRect();
    const x = (e.touches ? e.touches[0].clientX : e.clientX) - r.left;
    const p = Math.max(0, Math.min(1, x / r.width));
    const v = Math.round(min + p * (max - min));
    onChange?.(v);
  };
  React.useEffect(() => {
    if (!drag) return;
    const m = e => move(e);
    const u = () => setDrag(false);
    window.addEventListener('mousemove', m);
    window.addEventListener('mouseup', u);
    window.addEventListener('touchmove', m);
    window.addEventListener('touchend', u);
    return () => {
      window.removeEventListener('mousemove', m);
      window.removeEventListener('mouseup', u);
      window.removeEventListener('touchmove', m);
      window.removeEventListener('touchend', u);
    };
  });
  return (
    <div className="fc g4">
      <div className="f aic jcb" style={{ minHeight: 14 }}>
        <span className="t-script" style={{ color: 'var(--script-blue)', fontSize: 13 }}>{leftLabel}</span>
        <span className="t-script" style={{ color: 'var(--script-blue)', fontSize: 13 }}>{rightLabel}</span>
      </div>
      <div ref={ref} className="slider-track" style={{ height: 24 }}
        onMouseDown={(e) => { setDrag(true); move(e); }}
        onTouchStart={(e) => { setDrag(true); move(e); }}>
        <div className="slider-thumb" style={{ left: `${pct}%` }} />
      </div>
    </div>
  );
};

// Gold rule with diamonds at the ends
const GoldRule = ({ withDiamond = false }) => (
  <div className="f aic g8" style={{ color: 'var(--gold-primary)' }}>
    {withDiamond && <Diamond size={4} />}
    <span style={{ flex: 1, height: 1, background: 'currentColor', opacity: 0.85 }} />
    {withDiamond && <Diamond size={4} />}
  </div>
);

// Toast
const Toast = ({ text, onDismiss }) => {
  React.useEffect(() => {
    const t = setTimeout(onDismiss, 2600);
    return () => clearTimeout(t);
  }, []);
  return (
    <div className="stone fade-in" style={{
      position: 'absolute', top: 16, left: '50%', transform: 'translateX(-50%)',
      borderTop: '1px solid var(--gold-primary)',
      borderLeft: '1px solid rgba(212,175,92,0.2)',
      borderRight: '1px solid rgba(212,175,92,0.2)',
      borderBottom: '1px solid rgba(212,175,92,0.2)',
      padding: '8px 14px',
      fontFamily: 'var(--font-body)', fontSize: 13,
      color: 'var(--ink-dark)',
      zIndex: 100, maxWidth: 320, textAlign: 'center',
      boxShadow: '0 8px 30px rgba(0,0,0,0.5)',
    }}>{text}</div>
  );
};

Object.assign(window, {
  Diamond, DiamondRow, SectionHeader, StatusDot, Pill,
  RES, ResIcon, ResStrip,
  ARCHETYPE_GLYPHS, ArchetypeGlyph,
  truncAddr, Parchment, Stone, TopBar, TabBar, TickProgress, Slider, GoldRule, Toast,
});
