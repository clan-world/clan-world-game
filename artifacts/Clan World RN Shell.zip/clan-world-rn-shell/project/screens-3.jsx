// screens-3.jsx — Forge, Bazaar, Treasury, Whispers, Settings, Cockpit, Widget

// ── Sigil Forge (4-step mint) ──
const ForgeScreen = ({ onClose, onComplete }) => {
  const [step, setStep] = React.useState(1);
  const [name, setName] = React.useState('');
  const [arch, setArch] = React.useState(null);
  const [strat, setStrat] = React.useState({ trust: 0, aggression: 0, honesty: 0, solo: 0, builder: 0, vengeful: 0, cautious: 0 });
  const [forging, setForging] = React.useState(false);
  const [done, setDone] = React.useState(false);

  const archetypes = ['patient-builder', 'warlord', 'diplomat', 'hermit', 'trickster', 'verdant-warden'];

  const startForge = () => {
    setForging(true);
    setTimeout(() => { setForging(false); setDone(true); }, 1700);
    setTimeout(() => { onComplete({ name, archetype: arch, strategy: strat }); }, 2900);
  };

  return (
    <div className="fc" style={{ flex: 1, background: 'var(--bg-canvas)' }}>
      <TopBar title="SIGIL FORGE" onBack={onClose} />

      {/* Step indicator */}
      <div className="f aic jcc g10" style={{ padding: '12px 0', flexShrink: 0 }}>
        {[1, 2, 3, 4].map(i => (
          <React.Fragment key={i}>
            <Diamond size={i === step ? 9 : 6} color={i <= step ? 'var(--gold-bright)' : 'var(--gold-deeper)'} />
            {i < 4 && <span style={{ width: 24, height: 1, background: i < step ? 'var(--gold-primary)' : 'var(--gold-deeper)' }} />}
          </React.Fragment>
        ))}
      </div>

      <div className="scroll" style={{ flex: 1, overflowY: 'auto', padding: '0 16px 16px' }}>
        {step === 1 && (
          <div className="fc g14">
            <div className="h2" style={{ color: 'var(--gold-bright)', textAlign: 'center', marginTop: 4 }}>NAME YOUR ELDER</div>
            <input value={name} onChange={e => setName(e.target.value.slice(0, 16))}
              placeholder="A name in the realm…" maxLength={16}
              style={{
                background: 'var(--bg-elevated)', border: '1px solid var(--gold-deep)',
                color: 'var(--ink-dark)', padding: '14px 16px',
                fontFamily: 'var(--font-display)', fontSize: 18, letterSpacing: '0.06em',
                textAlign: 'center', outline: 'none',
              }} />
            <div className="t-mono" style={{ fontSize: 9, color: 'var(--ink-dark-faint)', textAlign: 'right' }}>{name.length}/16</div>

            <div className="rule-gold-soft" style={{ margin: '8px 0' }} />
            <div className="h2" style={{ color: 'var(--gold-bright)', textAlign: 'center' }}>CHOOSE AN ARCHETYPE</div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              {archetypes.map(a => {
                const active = arch === a;
                return (
                  <button key={a} onClick={() => setArch(a)} style={{
                    background: 'transparent', border: 'none', padding: 0, cursor: 'pointer',
                  }}>
                    <Parchment deep style={{
                      padding: 12, textAlign: 'center',
                      borderColor: active ? 'var(--gold-bright)' : 'var(--gold-deep)',
                      borderWidth: active ? 2 : 1,
                      boxShadow: active ? '0 0 0 2px rgba(232,199,126,0.3)' : 'none',
                    }}>
                      <div className="f jcc" style={{ marginBottom: 6 }}>
                        <ArchetypeGlyph kind={a} size={42} />
                      </div>
                      <div className="t-display" style={{ fontSize: 11, color: 'var(--ink-parchment)' }}>{ARCHETYPE_GLYPHS[a].name}</div>
                      <div className="t-body-i" style={{ fontSize: 10, color: 'var(--ink-parchment-muted)', marginTop: 4, lineHeight: 1.3 }}>
                        {ARCHETYPE_GLYPHS[a].short}
                      </div>
                    </Parchment>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="fc g12">
            <div className="h2" style={{ color: 'var(--gold-bright)', textAlign: 'center', marginTop: 4 }}>SHAPE THEIR WILL</div>
            <div className="t-body-i" style={{ fontSize: 12, color: 'var(--ink-dark-muted)', textAlign: 'center' }}>
              These can be tuned later. Choose how your Elder begins.
            </div>
            <Parchment deep style={{ padding: 14, marginTop: 4 }}>
              <div className="fc g14">
                {STRATEGY_AXES.map(ax => {
                  const v = strat[ax.key] ?? 0;
                  return (
                    <div key={ax.key} className="fc g4">
                      <div className="f jcb">
                        <span className="h3" style={{ color: 'var(--ink-parchment)', fontSize: 9 }}>{ax.key.toUpperCase()}</span>
                        <span className="t-mono" style={{ fontSize: 11, color: 'var(--ink-parchment)', fontWeight: 600 }}>{v > 0 ? `+${v}` : v}</span>
                      </div>
                      <SliderInk value={v} onChange={(nv) => setStrat(s => ({ ...s, [ax.key]: nv }))} />
                      <div className="f jcb">
                        <span className="t-script" style={{ fontSize: 11, color: '#3a4a7a' }}>{ax.left}</span>
                        <span className="t-script" style={{ fontSize: 11, color: '#3a4a7a' }}>{ax.right}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </Parchment>
          </div>
        )}

        {step === 3 && (
          <div className="fc g12">
            <div className="h2" style={{ color: 'var(--gold-bright)', textAlign: 'center', marginTop: 4 }}>BIND A MIND</div>
            <div className="t-body-i" style={{ fontSize: 12, color: 'var(--ink-dark-muted)', textAlign: 'center' }}>
              Choose the harness that will animate your Elder.
            </div>

            <Parchment deep style={{ padding: 16, marginTop: 8, borderColor: 'var(--gold-bright)', borderWidth: 2 }}>
              <div className="f jcb aic">
                <div className="fc g4">
                  <div className="t-display" style={{ fontSize: 16, color: 'var(--ink-parchment)' }}>CLAUDE-CODE</div>
                  <div className="t-mono" style={{ fontSize: 9, color: 'var(--ink-parchment-muted)' }}>v1 · TEE-ATTESTED</div>
                </div>
                <span style={{ color: 'var(--status-live)', fontSize: 14 }}>● SELECTED</span>
              </div>
              <div className="t-body-i" style={{ fontSize: 12, color: 'var(--ink-parchment-muted)', marginTop: 8 }}>
                Reasoning harness with persistent memory and tool use. Default for v1.
              </div>
            </Parchment>

            <div className="fc g6">
              {['CODEX', 'GROK', 'CUSTOM API'].map(h => (
                <Stone key={h} style={{ padding: 14, opacity: 0.5 }}>
                  <div className="f jcb aic">
                    <div className="t-display" style={{ fontSize: 13, color: 'var(--ink-dark-muted)' }}>{h}</div>
                    <span className="t-mono" style={{ fontSize: 9, color: 'var(--ink-dark-faint)', letterSpacing: '0.1em' }}>🔒 SOON</span>
                  </div>
                </Stone>
              ))}
            </div>
          </div>
        )}

        {step === 4 && !forging && !done && (
          <div className="fc g12">
            <div className="h2" style={{ color: 'var(--gold-bright)', textAlign: 'center', marginTop: 4 }}>FORGE THE SIGIL</div>
            <Parchment deep style={{ padding: 18, textAlign: 'center', marginTop: 6 }}>
              <div className="f jcc" style={{ marginBottom: 10 }}>
                <ArchetypeGlyph kind={arch} size={64} />
              </div>
              <div className="t-display-mixed" style={{ fontSize: 26, color: 'var(--ink-parchment)' }}>{name || '—'}</div>
              <div className="t-script" style={{ fontSize: 14, color: '#3a4a7a' }}>{ARCHETYPE_GLYPHS[arch]?.name}</div>

              <div className="rule-parchment" style={{ margin: '14px 0' }} />

              <div className="h3" style={{ color: 'var(--ink-parchment-muted)', fontSize: 9, textAlign: 'left', marginBottom: 8 }}>STRATEGY FINGERPRINT</div>
              <div className="fc g4" style={{ textAlign: 'left' }}>
                {STRATEGY_AXES.map(ax => (
                  <div key={ax.key} className="f jcb" style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--ink-parchment)' }}>
                    <span style={{ opacity: 0.7 }}>{ax.key}</span>
                    <span>{(strat[ax.key] ?? 0) > 0 ? `+${strat[ax.key]}` : strat[ax.key] ?? 0}</span>
                  </div>
                ))}
              </div>

              <div className="rule-parchment" style={{ margin: '14px 0' }} />

              <div className="f jcb">
                <span className="h3" style={{ color: 'var(--ink-parchment-muted)' }}>MINT FEE</span>
                <span className="t-mono" style={{ fontSize: 14, color: 'var(--ink-parchment)', fontWeight: 600 }}>5 GOLD</span>
              </div>
            </Parchment>
          </div>
        )}

        {(forging || done) && (
          <div className="fc aic jcc" style={{ padding: '40px 0 20px' }}>
            <div style={{
              width: 220, height: 220, position: 'relative',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }} className={forging ? 'burn-edge' : ''}>
              <Parchment deep style={{ width: 200, height: 200, padding: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
                <div className={done ? 'seal-stamp' : ''}>
                  <ArchetypeGlyph kind={arch} size={110} />
                </div>
                {/* Diamond ornaments */}
                <Diamond size={6} className="diamond-light-1" color="var(--gold-bright)" style={{ position: 'absolute', top: 10, left: '50%', transform: 'translateX(-50%) rotate(45deg)' }} />
                <Diamond size={6} className="diamond-light-2" color="var(--gold-bright)" style={{ position: 'absolute', bottom: 10, left: '50%', transform: 'translateX(-50%) rotate(45deg)' }} />
                <Diamond size={6} className="diamond-light-3" color="var(--gold-bright)" style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%) rotate(45deg)' }} />
                <Diamond size={6} className="diamond-light-1" color="var(--gold-bright)" style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%) rotate(45deg)' }} />
              </Parchment>
            </div>
            <div className="t-display" style={{ fontSize: 14, color: 'var(--gold-bright)', marginTop: 24, letterSpacing: '0.2em' }}>
              {done ? 'WELCOME TO YOUR HALL' : 'FORGING…'}
            </div>
            {done && (
              <div className="t-script" style={{ fontSize: 16, color: 'var(--script-blue)', marginTop: 8 }}>
                {name}
              </div>
            )}
          </div>
        )}
      </div>

      {!forging && !done && (
        <div style={{ flexShrink: 0, padding: 12, background: 'var(--bg-canvas)', borderTop: '1px solid rgba(212,175,92,0.3)', display: 'flex', gap: 8 }}>
          {step > 1 && <button className="btn btn-secondary" style={{ flex: 1 }} onClick={() => setStep(step - 1)}>← BACK</button>}
          {step < 4 && (
            <button className="btn btn-primary" style={{ flex: 2 }}
              disabled={(step === 1 && (!name.trim() || !arch))}
              onClick={() => setStep(step + 1)}>CONTINUE →</button>
          )}
          {step === 4 && (
            <button className="btn btn-primary" style={{ flex: 2 }} onClick={startForge}>FORGE · 5 GOLD</button>
          )}
        </div>
      )}
    </div>
  );
};

// ── Bazaar ──
const BazaarScreen = ({ onOpenInft }) => {
  const [tab, setTab] = React.useState('FOR HIRE');
  return (
    <>
      <TopBar title="THE BAZAAR" />
      <div className="f" style={{ borderBottom: '1px solid rgba(212,175,92,0.2)', flexShrink: 0 }}>
        {['FOR HIRE', 'FOR SALE'].map(t => (
          <button key={t} onClick={() => setTab(t)} style={{
            flex: 1, background: 'transparent', border: 'none', cursor: 'pointer',
            padding: '12px', fontFamily: 'var(--font-display)', fontSize: 11, letterSpacing: '0.16em',
            color: tab === t ? 'var(--gold-bright)' : 'var(--ink-dark-faint)',
            borderBottom: `2px solid ${tab === t ? 'var(--gold-bright)' : 'transparent'}`,
          }}>{t}</button>
        ))}
      </div>
      <div style={{ padding: '10px 14px', flexShrink: 0 }}>
        <div className="f g6 scroll" style={{ overflowX: 'auto' }}>
          <button className="chip">ARCHETYPES ▾</button>
          <button className="chip">ELO 1000+ ▾</button>
          <button className="chip" style={{ color: 'var(--gold-primary)', borderColor: 'var(--gold-deep)' }}>SORT: TOP RANKED ▾</button>
        </div>
      </div>
      <div className="scroll" style={{ flex: 1, overflowY: 'auto', padding: '4px 14px 20px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        {tab === 'FOR HIRE' ? BAZAAR_INFTS.map(i => (
          <InftCard key={i.id} inft={i} onClick={() => onOpenInft(i)} hireFee={i.hireFee} sparkline={i.sparkline} />
        )) : (
          <Parchment deep style={{ marginTop: 20, textAlign: 'center', padding: 28 }}>
            <div className="t-script" style={{ fontSize: 17, color: '#3a4a7a' }}>The Bazaar is quiet.</div>
            <div className="t-body" style={{ fontSize: 12, color: 'var(--ink-parchment)', marginTop: 8 }}>No Elders are for sale today.</div>
          </Parchment>
        )}
      </div>
    </>
  );
};

// ── Hire Confirmation Modal ──
const HireModal = ({ inft, onCancel, onConfirm }) => (
  <div style={{ position: 'absolute', inset: 0, background: 'rgba(7,7,10,0.7)', zIndex: 50, display: 'flex', alignItems: 'flex-end' }} onClick={onCancel}>
    <div onClick={e => e.stopPropagation()} className="sheet-up" style={{ width: '100%', background: 'var(--bg-elevated)', borderTop: '1px solid var(--gold-primary)', borderRadius: '8px 8px 0 0', padding: 20 }}>
      <div className="f jcc" style={{ marginBottom: 6 }}>
        <div style={{ width: 40, height: 3, background: 'var(--gold-deep)', borderRadius: 2 }} />
      </div>
      <div className="h2" style={{ textAlign: 'center', color: 'var(--gold-bright)', margin: '8px 0 14px' }}>CONFIRM HIRE</div>
      <Parchment deep style={{ padding: 14 }}>
        <div className="f g12 aic">
          <ArchetypeGlyph kind={inft.archetype} size={48} />
          <div className="fc g2" style={{ flex: 1 }}>
            <div className="t-display-mixed" style={{ fontSize: 20, color: 'var(--ink-parchment)' }}>{inft.name}</div>
            <div className="t-script" style={{ fontSize: 12, color: '#3a4a7a' }}>{ARCHETYPE_GLYPHS[inft.archetype].name}</div>
            <div className="t-mono" style={{ fontSize: 10, color: 'var(--ink-parchment-muted)', marginTop: 2 }}>ELO {inft.elo}</div>
          </div>
          <div className="t-mono" style={{ fontSize: 13, color: 'var(--ink-parchment)', fontWeight: 600 }}>{inft.hireFee}</div>
        </div>
      </Parchment>
      <div className="t-body-i" style={{ fontSize: 12, color: 'var(--ink-dark-muted)', textAlign: 'center', margin: '14px 8px', lineHeight: 1.5 }}>
        The Elder serves your hall for one season. Strategy is locked. Prizes flow to you. Memory is retained by the owner.
      </div>
      <div className="f g8" style={{ marginTop: 4 }}>
        <button className="btn btn-secondary" style={{ flex: 1 }} onClick={onCancel}>CANCEL</button>
        <button className="btn btn-primary" style={{ flex: 1.4 }} onClick={onConfirm}>CONFIRM · {inft.hireFee?.split(' ')[0]} GOLD</button>
      </div>
    </div>
  </div>
);

// ── Treasury ──
const TreasuryScreen = ({ onBuyGold, onTx }) => (
  <>
    <TopBar title="TREASURY" />
    <div className="scroll" style={{ flex: 1, overflowY: 'auto', padding: '12px 14px 20px', display: 'flex', flexDirection: 'column', gap: 16 }}>
      {/* Identity */}
      <div className="f aic g12" style={{ padding: '4px 0' }}>
        <div style={{ width: 44, height: 44, borderRadius: '50%', background: 'linear-gradient(135deg, var(--aubergine-deep), var(--gold-deeper))', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1px solid var(--gold-primary)' }}>
          <Diamond size={12} color="var(--gold-bright)" />
        </div>
        <div className="fc g2" style={{ flex: 1 }}>
          <div className="t-display-mixed" style={{ fontSize: 16, color: 'var(--ink-dark)' }}>aelder.sol</div>
          <div className="t-mono" style={{ fontSize: 10, color: 'var(--ink-mono)' }}>0x4f2a…81d3 ⎘</div>
        </div>
      </div>

      <Parchment deep style={{ padding: 0 }}>
        <div style={{ padding: '14px 16px 12px' }}>
          <div className="f aic g8">
            <ResIcon kind="gold" size={16} />
            <span className="h3" style={{ color: 'var(--ink-parchment-muted)' }}>GOLD</span>
          </div>
          <div className="f aib g6" style={{ marginTop: 4 }}>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 38, fontWeight: 600, color: 'var(--ink-parchment)', lineHeight: 1 }}>247</span>
            <span className="t-mono" style={{ fontSize: 11, color: 'var(--ink-parchment-muted)' }}>≈ $24.70</span>
          </div>
          <div className="rule-parchment" style={{ margin: '12px 0' }} />
          <div className="f jcb">
            <span className="h3" style={{ color: 'var(--ink-parchment-muted)' }}>SOL · BASE SEPOLIA</span>
            <div className="t-mono" style={{ fontSize: 13, color: 'var(--ink-parchment)' }}>0.42 / 0.018</div>
          </div>
        </div>
        <div style={{ padding: 12, background: 'rgba(26,20,16,0.06)', borderTop: '1px solid rgba(26,20,16,0.18)' }}>
          <button className="btn btn-primary btn-block" onClick={onBuyGold}>BUY GOLD ↗</button>
        </div>
      </Parchment>

      <div className="fc g8">
        <SectionHeader>RECENT MOVEMENTS</SectionHeader>
        <div className="fc">
          {TXS.map((t, i) => (
            <div key={t.id} className="f aic g10" style={{ padding: '10px 4px', borderBottom: i < TXS.length - 1 ? '1px solid rgba(212,175,92,0.1)' : 'none', cursor: 'pointer' }} onClick={() => onTx(t)}>
              <span style={{ width: 20, textAlign: 'center', color: t.status === 'danger' ? 'var(--status-danger)' : t.status === 'live' ? 'var(--status-live)' : 'var(--gold-primary)', fontSize: 14 }}>{t.icon}</span>
              <div className="fc" style={{ flex: 1 }}>
                <div className="t-body" style={{ fontSize: 13, color: 'var(--ink-dark)' }}>{t.title}</div>
                <div className="t-body" style={{ fontSize: 11, color: 'var(--ink-dark-muted)' }}>{t.sub}</div>
              </div>
              <div className="fc" style={{ textAlign: 'right' }}>
                <div className="t-mono" style={{ fontSize: 12, color: t.amount.startsWith('+') ? 'var(--status-live)' : t.amount.startsWith('−') ? 'var(--status-danger)' : 'var(--ink-dark-muted)' }}>{t.amount}</div>
                <div className="t-mono" style={{ fontSize: 9, color: 'var(--ink-dark-faint)' }}>{t.t}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  </>
);

// ── Whispers Inbox ──
const WhispersScreen = ({ onBack }) => {
  const groups = WHISPERS.reduce((acc, w) => {
    acc[w.day] = acc[w.day] || []; acc[w.day].push(w); return acc;
  }, {});
  const dayLabels = { today: 'TODAY', yesterday: 'YESTERDAY', 'wed-6-may': 'WED · 6 MAY' };
  return (
    <>
      <TopBar title="WHISPERS" onBack={onBack} />
      <div style={{ padding: '10px 14px', flexShrink: 0 }}>
        <div className="f g6 scroll" style={{ overflowX: 'auto' }}>
          <button className="chip chip-active">ALL</button>
          <button className="chip">GAME</button>
          <button className="chip">MARKET</button>
          <button className="chip">SYSTEM</button>
        </div>
      </div>
      <div className="scroll" style={{ flex: 1, overflowY: 'auto', padding: '4px 14px 20px' }}>
        {Object.entries(groups).map(([day, items]) => (
          <div key={day} className="fc g4" style={{ marginBottom: 14 }}>
            <div className="h3" style={{ color: 'var(--ink-dark-muted)', padding: '8px 0' }}>{dayLabels[day]}</div>
            {items.map(w => (
              <div key={w.id} className="f aic g10" style={{ padding: '10px 0', borderBottom: '1px solid rgba(212,175,92,0.1)' }}>
                {w.unread ? <Diamond size={5} color="var(--gold-bright)" /> : <span style={{ width: 5 }} />}
                <span style={{ fontSize: 16, width: 20, textAlign: 'center', color: w.kind === 'danger' ? 'var(--status-danger)' : w.kind === 'live' ? 'var(--status-live)' : w.kind === 'warn' ? 'var(--status-warn)' : 'var(--gold-primary)' }}>{w.icon}</span>
                <div className="fc" style={{ flex: 1, minWidth: 0 }}>
                  <div className="t-body" style={{ fontSize: 13, color: 'var(--ink-dark)', fontWeight: w.unread ? 600 : 400 }}>{w.title}</div>
                  <div className="t-body" style={{ fontSize: 11, color: 'var(--ink-dark-muted)' }}>{w.snippet}</div>
                </div>
                <div className="t-mono" style={{ fontSize: 9, color: 'var(--ink-dark-faint)' }}>{w.t}</div>
              </div>
            ))}
          </div>
        ))}
      </div>
    </>
  );
};

// ── Codex (Settings) ──
const CodexScreen = ({ onBack }) => {
  const [haptics, setHaptics] = React.useState(true);
  const [game, setGame] = React.useState(true);
  const [market, setMarket] = React.useState(true);
  const [system, setSystem] = React.useState(false);
  return (
    <>
      <TopBar title="CODEX" onBack={onBack} />
      <div className="scroll" style={{ flex: 1, overflowY: 'auto', padding: '12px 14px 20px', display: 'flex', flexDirection: 'column', gap: 18 }}>
        <SettingGroup label="WALLET">
          <SettingRow label="Connected address" value="0x4f2a…81d3" mono />
          <SettingRow label="" right={<button className="btn btn-secondary" style={{ padding: '6px 10px', fontSize: 10 }}>DISCONNECT</button>} />
        </SettingGroup>

        <SettingGroup label="NOTIFICATIONS">
          <SettingRow label="Game (raids, prizes)" right={<Toggle on={game} onClick={() => setGame(!game)} />} />
          <SettingRow label="Market (hire offers)" right={<Toggle on={market} onClick={() => setMarket(!market)} />} />
          <SettingRow label="System" right={<Toggle on={system} onClick={() => setSystem(!system)} />} />
          <SettingRow label="Quiet hours" value="22:00 → 08:00" mono />
        </SettingGroup>

        <SettingGroup label="HAPTICS">
          <SettingRow label="Master haptics" right={<Toggle on={haptics} onClick={() => setHaptics(!haptics)} />} />
          <SettingRow label="Intensity" value="MEDIUM" mono />
        </SettingGroup>

        <SettingGroup label="WIDGET">
          <SettingRow label="Mirror game" value="STORM RIDERS" mono />
          <SettingRow label="Refresh" value="60s" mono />
        </SettingGroup>

        <SettingGroup label="ABOUT">
          <SettingRow label="Version" value="0.4.1 · ALPHA" mono />
          <SettingRow label="Network" value="BASE SEPOLIA" mono />
          <SettingRow label="View source" right={<span style={{ color: 'var(--gold-primary)', fontSize: 13 }}>↗</span>} />
        </SettingGroup>
      </div>
    </>
  );
};

const SettingGroup = ({ label, children }) => (
  <div className="fc g6">
    <div className="h3" style={{ color: 'var(--ink-dark-muted)' }}>{label}</div>
    <div className="rule-gold-soft" />
    <div className="fc">{children}</div>
  </div>
);

const SettingRow = ({ label, value, mono, right }) => (
  <div className="f jcb aic" style={{ padding: '10px 0', borderBottom: '1px solid rgba(212,175,92,0.07)' }}>
    <span className="t-body" style={{ fontSize: 13, color: 'var(--ink-dark)' }}>{label}</span>
    {value && <span className={mono ? 't-mono' : 't-body'} style={{ fontSize: mono ? 11 : 13, color: mono ? 'var(--ink-mono)' : 'var(--ink-dark-muted)' }}>{value}</span>}
    {right}
  </div>
);

const Toggle = ({ on, onClick }) => (
  <button onClick={onClick} style={{
    width: 36, height: 20, borderRadius: 10, border: 'none', cursor: 'pointer',
    background: on ? 'var(--gold-primary)' : 'var(--bg-elevated-2)',
    position: 'relative', transition: 'background 0.18s',
  }}>
    <span style={{
      position: 'absolute', top: 2, left: on ? 18 : 2,
      width: 16, height: 16, borderRadius: '50%',
      background: on ? '#1A1410' : 'var(--ink-dark-muted)',
      transition: 'left 0.18s',
    }} />
  </button>
);

// ── Cockpit (WebView mock) ──
const CockpitScreen = ({ inft, onClose, onWhisper }) => (
  <div className="fc" style={{ flex: 1, background: 'var(--bg-terminal)' }}>
    <div className="f aic jcb" style={{
      padding: '8px 12px',
      background: 'rgba(15,14,18,0.92)',
      borderBottom: '1px solid rgba(212,175,92,0.3)',
      flexShrink: 0,
    }}>
      <button onClick={onClose} style={{ background: 'transparent', border: 'none', color: 'var(--gold-primary)', fontSize: 13, cursor: 'pointer', fontFamily: 'var(--font-display)', letterSpacing: '0.1em' }}>← HALL</button>
      <div className="t-mono" style={{ fontSize: 10, color: 'var(--ink-mono)' }}>TICK {inft.gameTick} · S{inft.season} · {Math.round(inft.seasonPct * 100)}%</div>
      <button onClick={onWhisper} style={{ background: 'transparent', border: 'none', color: 'var(--gold-bright)', fontSize: 16, cursor: 'pointer' }}>♪</button>
    </div>

    <div className="scroll" style={{ flex: 1, overflowY: 'auto', padding: 12, fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--ink-mono)' }}>
      {/* Cockpit terminal mock */}
      <div className="fc g14">
        <div>
          <div style={{ color: 'var(--gold-bright)', letterSpacing: '0.16em', marginBottom: 6 }}>◆ TERM — CRIMSON</div>
          <div className="rule-gold-soft" />
          <div style={{ marginTop: 8, lineHeight: 1.7 }}>
            <div><span style={{ color: 'var(--ink-dark-muted)' }}>T259</span> &gt; observe.bandit_ne</div>
            <div><span style={{ color: 'var(--ink-dark-muted)' }}>T259</span> &gt; <span style={{ color: 'var(--status-danger)' }}>raid.detected</span> resource=wood loss=2</div>
            <div><span style={{ color: 'var(--ink-dark-muted)' }}>T259</span> &gt; recall.strategy.cautious=+2 → no_pursue</div>
            <div><span style={{ color: 'var(--ink-dark-muted)' }}>T259</span> &gt; whisper.from(owner)="watch the bandit camp"</div>
            <div><span style={{ color: 'var(--ink-dark-muted)' }}>T259</span> &gt; mood.set=cautious; pact.verdant=hold</div>
            <div><span style={{ color: 'var(--ink-dark-muted)' }}>T260</span> &gt; <span style={{ color: 'var(--status-live)' }}>commit.tick</span></div>
          </div>
        </div>

        <div>
          <div style={{ color: 'var(--gold-bright)', letterSpacing: '0.16em', marginBottom: 6 }}>◆ VAULT — CLAN 2</div>
          <div className="rule-gold-soft" />
          <div style={{ marginTop: 8 }}>
            <div className="f jcb"><span>GOLD</span><span><span style={{ color: 'var(--status-live)' }}>4</span> live</span></div>
            <div className="f jcb"><span>WOOD</span><span><span style={{ color: 'var(--status-danger)' }}>1</span> live</span></div>
            <div className="f jcb"><span>IRON</span><span><span style={{ color: 'var(--status-live)' }}>2</span> live</span></div>
            <div className="f jcb"><span>WHEAT</span><span><span style={{ color: 'var(--status-live)' }}>5</span> live</span></div>
            <div className="f jcb"><span>FISH</span><span><span style={{ color: 'var(--ink-dark-muted)' }}>0</span> idle</span></div>
            <div className="f jcb"><span>BLUEPRINT</span><span><span style={{ color: 'var(--status-live)' }}>1</span> live</span></div>
          </div>
        </div>

        <div>
          <div style={{ color: 'var(--gold-bright)', letterSpacing: '0.16em', marginBottom: 6 }}>◆ 0G — ATTESTATION</div>
          <div className="rule-gold-soft" />
          <div style={{ marginTop: 8, lineHeight: 1.7, color: 'var(--ink-dark-muted)' }}>
            <div>tee.attest=ok ratchet=259</div>
            <div>kv.commit=0xa14b…cdf2</div>
            <div>memory.crud_ops=4 bytes=812</div>
          </div>
        </div>

        <div className="t-body-i" style={{ color: 'var(--ink-dark-muted)', textAlign: 'center', padding: '12px 0' }}>
          ── live cockpit · WebView ──
        </div>
      </div>
    </div>
  </div>
);

// ── Bridge loader ──
const BridgeScreen = () => (
  <div className="fc aic jcc" style={{ flex: 1, background: 'var(--bg-terminal)', gap: 18, padding: 30 }}>
    <DiamondRow />
    <Diamond size={18} color="var(--gold-bright)" className="pulse" />
    <div className="t-display" style={{ fontSize: 13, color: 'var(--gold-bright)', letterSpacing: '0.2em' }}>ENTERING STORM RIDERS</div>
    <div className="fc aic g4" style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--ink-dark-muted)', textAlign: 'center', lineHeight: 1.7 }}>
      <div>resolving INFT context</div>
      <div>authorizing convex session</div>
      <div>injecting clanworld bridge</div>
    </div>
    <DiamondRow />
  </div>
);

// ── MWA Sheet ──
const MWASheet = ({ action, onCancel, onApprove }) => (
  <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.7)', zIndex: 200, display: 'flex', alignItems: 'flex-end' }} onClick={onCancel}>
    <div onClick={e => e.stopPropagation()} className="sheet-up" style={{ width: '100%', background: '#1d1b20', borderRadius: '16px 16px 0 0', padding: '20px 20px 28px', color: '#e6e1e5', fontFamily: 'Roboto, system-ui, sans-serif' }}>
      <div className="f jcc" style={{ marginBottom: 12 }}>
        <div style={{ width: 32, height: 4, background: '#49454f', borderRadius: 2 }} />
      </div>
      <div className="f aic g10" style={{ marginBottom: 16 }}>
        <div style={{ width: 36, height: 36, borderRadius: 8, background: 'linear-gradient(135deg, #ab9ff2, #5e4fff)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700 }}>P</div>
        <div className="fc">
          <div style={{ fontSize: 15, fontWeight: 500 }}>Phantom</div>
          <div style={{ fontSize: 12, color: '#9a8e72' }}>Mobile Wallet Adapter</div>
        </div>
      </div>
      <div style={{ fontSize: 13, color: '#cac4d0', marginBottom: 16, lineHeight: 1.5 }}>
        Clan World requests your signature to:
      </div>
      <div style={{ background: '#2b2930', borderRadius: 8, padding: 12, marginBottom: 16, fontSize: 13 }}>
        {action || 'Sign a transaction'}
      </div>
      <div className="f g8">
        <button className="btn btn-secondary" style={{ flex: 1, color: '#e6e1e5', borderColor: '#49454f', borderRadius: 100 }} onClick={onCancel}>Cancel</button>
        <button onClick={onApprove} style={{ flex: 1.4, background: '#ab9ff2', border: 'none', color: '#1d1b20', borderRadius: 100, padding: '12px 16px', fontWeight: 500, fontSize: 13, cursor: 'pointer', fontFamily: 'inherit' }}>Approve</button>
      </div>
    </div>
  </div>
);

Object.assign(window, {
  ForgeScreen, BazaarScreen, HireModal, TreasuryScreen,
  WhispersScreen, CodexScreen, SettingGroup, SettingRow, Toggle,
  CockpitScreen, BridgeScreen, MWASheet,
});
